public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean testPythagorean = new Pythagorean();
        System.out.println(testPythagorean.calculateHypotenuse(3,5));
    }
}